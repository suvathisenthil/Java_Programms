package org;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.stock.Item;

public class Solution {
	public static void main(String[] args) throws IOException {
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		Item item = null;
		switch(Integer.valueOf(bf.readLine())) {
		case 1:
			item = new Item(bf.readLine(), bf.readLine(), bf.readLine(), Double.valueOf(bf.readLine()), bf.readLine(), bf.readLine(), Float.valueOf(bf.readLine()));
			break;
		default:
			item = new Item(bf.readLine(), bf.readLine(), bf.readLine(), Double.valueOf(bf.readLine()), bf.readLine(), bf.readLine());
			break;
		}
		System.out.println(item);
		switch(Integer.valueOf(bf.readLine())) {
		case 1:
			item.applyDiscount();
			break;
		case 2:
			item.applyDiscount(Float.valueOf(bf.readLine()));
			break;
		case 3:
			item.removeDiscount();
			break;
		}
		if(item.getDiscountPercentage() == 0.0) {
			System.out.println("No Discount. Better Luck Next Time");
		} else {
			System.out.println("Discount Applied. :)");
		}
		System.out.println(item);
	}
}
