package com.stock;

public class Item {
	private String identity;
    private String name;
    private String manufacturer;
    private double maximumRetailPrice;
    private String manufacturedDate;
    private String expiryDate;
    private float discountPercentage;
    private double discountPrice;
	public Item(String identity, String name, String manufacturer, double maximumRetailPrice, String manufacturedDate,
			String expiryDate, float discountPercentage) {
		super();
		this.identity = identity;
		this.name = name;
		this.manufacturer = manufacturer;
		this.maximumRetailPrice = maximumRetailPrice;
		this.manufacturedDate = manufacturedDate;
		this.expiryDate = expiryDate;
		this.discountPercentage = discountPercentage;
		this.discountPrice = maximumRetailPrice;
	}
	public Item(String identity, String name, String manufacturer, double maximumRetailPrice, String manufacturedDate,
			String expiryDate) {
		super();
		this.identity = identity;
		this.name = name;
		this.manufacturer = manufacturer;
		this.maximumRetailPrice = maximumRetailPrice;
		this.manufacturedDate = manufacturedDate;
		this.expiryDate = expiryDate;
		this.discountPercentage = 0;
		this.discountPrice = maximumRetailPrice;
	}
	public String getIdentity() {
		return identity;
	}
	public void setIdentity(String identity) {
		this.identity = identity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public double getMaximumRetailPrice() {
		return maximumRetailPrice;
	}
	public void setMaximumRetailPrice(double maximumRetailPrice) {
		this.maximumRetailPrice = maximumRetailPrice;
	}
	public String getManufacturedDate() {
		return manufacturedDate;
	}
	public void setManufacturedDate(String manufacturedDate) {
		this.manufacturedDate = manufacturedDate;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public float getDiscountPercentage() {
		return discountPercentage;
	}
	public void setDiscountPercentage(float discountPercentage) {
		this.discountPercentage = discountPercentage;
	}
	public double getDiscountPrice() {
		return discountPrice;
	}
	public void applyDiscount() {
		this.discountPrice = this.maximumRetailPrice - ((this.discountPercentage / 100) * this.maximumRetailPrice);
	}
	public void applyDiscount(float discountPercentage) {
		this.setDiscountPercentage(discountPercentage);
		this.discountPrice = this.maximumRetailPrice - ((this.discountPercentage / 100) * this.maximumRetailPrice);
	}
	public void removeDiscount() {
		this.setDiscountPercentage(0);
		this.discountPrice = this.maximumRetailPrice;
	}
	public String toString() {
		return String.format("%-30s : %s\n%-30s : %s\n%-30s : %s\n%-30s : %s\n%-30s : %s\n%-30s : Rs.%.2f\n%-30s : %.2f\n%-30s : Rs.%.2f", "Item Identity", this.identity, "Item Name", this.name, "Item Manufacturer", this.manufacturer, "Item Manufacturing Date", this.manufacturedDate, "Item Expiry Date", this.expiryDate, "Maximum Retail Price", this.maximumRetailPrice, "Discount Percentage", this.discountPercentage, "Discount Amount", this.discountPrice);
	}    
}
