package com.sbi;
public class Transaction {
	long accountNumber;
	String accountHolder;
	String accountType;
	double balance;
  
	public String toString() {
		return String.format("%s: ","Account Number")+String.format("%016d",this.accountNumber)+String.format("\n%s: ","Account Holder")+this.accountHolder+String.format("\n%s: ","Account Type")+this.accountType+String.format("\n%s: Rs.","Balance")+String.format("%.2f",this.balance);
	}
	public Transaction (long accountNumber,String accountHolder,String accountType,double balance) {
		this.accountNumber = accountNumber;
		this.accountHolder = accountHolder;
		this.accountType = accountType;
		this.balance = balance;
	}

	public boolean withdraw(double amount) {
        
		if(amount > 0 && amount < 2001) {
			this.balance = this.balance - amount;
            return true;
		}
		else {
            return false;
		}
	}
	public boolean deposit(double amount) {
        
		if(amount > 99 && amount < 100001 ) {
			this.balance = this.balance + amount;
            return true;
		}
		else {
            return false;
		}
	}
	public void balance(){
		System.out.println("Available Balance : "+String.format("Rs.%.2f",this.balance));
	}
}