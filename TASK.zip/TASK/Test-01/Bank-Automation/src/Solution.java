package org;
import com.sbi.Transaction;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
public class Solution {
	public static void main(String args[]) throws IOException {
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        Transaction banktransaction = new Transaction(Long.valueOf(bf.readLine()),bf.readLine(),bf.readLine(),Double.valueOf(bf.readLine()));
        double d;
        switch(Integer.valueOf(bf.readLine())) {
			case 1 :
                d = Double.valueOf(bf.readLine());
                System.out.println(banktransaction);
				if(banktransaction.deposit(d)) {
					System.out.println("Success Transaction - Deposit");
				}
				else {
					System.out.println("Failed Transaction - Deposit");
				}
				break;
			case 2 :
                d = Double.valueOf(bf.readLine());
                System.out.println(banktransaction);
				if(banktransaction.withdraw(d)){
					System.out.println("Success Transaction - Withdraw");
				}
				else {
					System.out.println("Failed Transaction - Withdraw");
				}
				break;				
			case 3 :
				System.out.println(banktransaction);
                banktransaction.balance();
				break;
		}
		System.out.println(banktransaction);
	}
}