public class Complex {
	public Complex() {
		real = 0;
		imaginary = 0;
	}
	public Complex(int a) {
		real = a;
	}
	public Complex(double b) {
		imaginary = (int)b;
	}
	public Complex(int ab,int bb) {
		real = ab;
		imaginary = bb;
	}

	int real = 0;
	int imaginary = 0;
	public void add(int re, int im) {
		int result1 = (re + real);
		int result2 = (im + imaginary);
		if (result2 > 0)
			System.out.println("Addition :"+result1+"+"+result2+"j");
		else
			System.out.println("Addition :"+result1+""+result2+"j");

	}
	public void sub(int rl,int il) {
		int result1 = (rl - real);
		int result2 = (il - imaginary);
		if (result2 > 0)
			System.out.println("Subtraction :"+result1+"+"+result2+"j");
		else
			System.out.println("Subtraction :"+result1+""+result2+"j");
	}
	public void isReal() {
		if(real != 0) {
			System.out.println("Real");
		}
		else
			System.out.println("Not Real");

	}
	public void isImaginary() {
		if(real == 0) {
			System.out.println("Imaginary");
		}
		else {
			System.out.println("Not Imaginary");
		}

	}

	public void print() {
		System.out.println(real+"+"+imaginary+"j");
	}
}