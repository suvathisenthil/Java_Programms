import java.util.Scanner;
public class Solution {
	public static void main(String args[]) {
		Complex c = null;
		Scanner in = new Scanner(System.in);
		int a,b;
		a=in.nextInt();
		switch(a) {
			case 1:
				c = new Complex();
				break;
			case 2:
				c = new Complex(in.nextInt());
				break;
			case 3:
				c = new Complex(in.nextDouble());
				break;
			case 4:
				c = new Complex(in.nextInt(), in.nextInt());
				break;
			
		}
		b = in.nextInt();
		switch(b) {
			case 1:
				c.add(-5,-7);
				break;
			case 2:
				c.sub(10,20);
				break;
			case 3:
				c.isReal();
				break;
			case 4:
				c.isImaginary();
				break;


		}
		c.print();
		

		

	}
}