public class Point {
	public Point() {
		x = 5;
		y = 5;
	}
	public Point(int sss) {
		x = sss;
		y = sss;
	}
	public Point(int ab,int bb) {
		x = ab;
		y = bb;
	}
	public Point(double ab,double bb) {
		x = (int)ab;
		y = (int)bb;
	}
	public Point(int ab,double bb) {
		x = ab;
		y = (int)bb;
	}
	int x;
	int y;
	public void distance(int xs, int ys) {
		double ac = Math.pow((x + xs), 2);
		double bc = Math.pow((y + ys), 2);
		double result = Math.sqrt(ac + bc);
		System.out.println("Difference :"+result);
	}
	public void print() {
		System.out.println("("+x+" ,"+y+")");
	}
}