import java.util.Scanner;
public class Solu {
	public static void main(String args[]) {
		Point p = null;
		Scanner in = new Scanner(System.in);
		int a;
		a=in.nextInt();
		switch(a) {
			case 1:
				p = new Point();
				break;
			case 2:
				int s;
				s = in.nextInt();
				p = new Point(s);
				break;
			case 3:
				int r;
				s = in.nextInt();
				r = in.nextInt();
				p = new Point(s,r);
				break;
			case 4:
				double ss,rr;
				ss = in.nextDouble();
				rr = in.nextDouble();
				p = new Point(ss,rr);
				break;
			case 5:
				int n;
				double m;
				n = in.nextInt();
				m = in.nextDouble();
				p = new Point(n,m);
				break;
		}
		p.print();
		p.distance(10,20);

		

	}
}