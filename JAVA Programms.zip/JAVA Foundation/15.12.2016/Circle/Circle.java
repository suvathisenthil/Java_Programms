public class Circle {
	double radius;
	static double pi;
	public void area() {
		System.out.println("Area of circle :"+(radius*radius*pi));
	}
}