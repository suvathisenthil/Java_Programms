public class Solution {
	public static void main(String args[]) {
		Circle obj = new Circle();
		obj.radius = 5.46;
		Circle.pi = 3.14;
		//obj.pi = 3.14;
		obj.area();
		Circle obj1 = new Circle();
		obj1.radius = 5.46;
		//obj1.pi = 9.46;
		obj1.area();

	}
}