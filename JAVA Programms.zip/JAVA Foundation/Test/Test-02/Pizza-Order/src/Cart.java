package com.hut;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import com.account.Address;
import com.hut.cmp.IdentityComparator;

public class Cart  {
	private String name;
	private Address address;
	private List<Pizza> orders = new LinkedList<Pizza>();
	private double totalAmount;
	public Cart(String name, Address address) {
		super();
		this.name = name;
		this.address = address;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	
	public void addPizza(Pizza pizza) {
		orders.add(pizza);
	}
	
	public void removePizza(Pizza pizza) {
		orders.remove(pizza);			
	}
	@Override
	public String toString() {
		orders.sort(new IdentityComparator());
		System.out.println("----------------------------------------------------------------------------------------");
		System.out.println(String.format("%-5s %-20s %-40s %-10s %s","ID","NAME OF PIZZA","TOPPINGS","SIZE","PRICE"));
		System.out.println("----------------------------------------------------------------------------------------");
		totalAmount = 0;
		for(Pizza ob : orders) {
		//	System.out.println(String.format("%-5s%-20s%-40s%-10s%.2f",orders.get(1),orders.get(2),orders.get(3),orders.get(4),orders.get(5)));
			totalAmount = totalAmount + ob.getPrice();
			System.out.println(ob);
		}
		System.out.println("----------------------------------------------------------------------------------------");
		return String.format("*** PAY Rs.%.2f ***",totalAmount);
	}
}
