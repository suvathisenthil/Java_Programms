package shape.round;
public class Circle {
	static double pi;
	double radius; 	
	static {
		System.out.println("static ");
		Circle.pi = 3.14;
		Circle.print();
		Circle aa = new Circle(3.36);
		aa.area();
	}
	static void print(){
		System.out.println("\t\t Circle ");

	} 
	public Circle(double radius) {
		System.out.println("instance");
		this.radius = radius;
	}
	public void area() {
		System.out.println("Area of circle :"+(this.radius * this.radius * pi));
	}
}