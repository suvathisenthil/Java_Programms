package com.wipro;
import shape.round.Circle;
import java.util.Scanner;
public class Solution {
	public static void main(String args[]) {
		Circle circle = new Circle (21.56);
		circle.area();
		Circle circle1 = new Circle (8.336);
		circle1.area();
		Circle circle2 = new Circle (12.56);
		circle2.area();
	}
}