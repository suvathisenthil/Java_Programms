public class BankTransaction {
	long accountNumber;
	String accountHolder;
	String accountType;
	double balance;
	public String toString() {
		return String.format("%-25s : ","Account Number")+String.format("%016d",this.accountNumber)+String.format("\n%-25s : ","Account Holder")+this.accountHolder+String.format("\n%-25s : ","Account Type")+this.accountType+String.format("\n%-25s : Rs","Balance")+String.format("%.2f",this.balance);
	}
	public BankTransaction (long accountNumber,String accountHolder,String accountType,double balance) {
		this.accountNumber = accountNumber;
		this.accountHolder = accountHolder;
		this.accountType = accountType;
		this.balance = balance;
	}

	void withdraw(double amount) {
		if(this.balance > amount) {
			System.out.println("Success Transaction - Withdraw -Rs."+String.format("%.2f",amount));
		}
		else {
			System.out.println("Unsccess Transaction - Withdraw -Rs."+String.format("%.2f",amount));
		}
		this.balance = this.balance - amount;
	}
	void deposit(double amount) {
		if(amount >= 99.00 && amount <= 200000.00) {
			System.out.println("Success Transaction - Deposit -Rs."+String.format("%.2f",amount));
		}
		else {
			System.out.println("Unsccess Transaction - Deposit -Rs."+String.format("%.2f",amount));
		}
		this.balance = this.balance + amount;
	}
	void balanceEnquiry() {
		System.out.println("Available Balance Rs."+String.format("%.2f",this.balance));
	}
}