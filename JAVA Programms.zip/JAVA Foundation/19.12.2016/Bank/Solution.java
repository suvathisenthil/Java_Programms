import java.util.Scanner;
public class Solution {
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		BankTransaction banktransaction = new BankTransaction(872361871233L,"Steve Jobs","Current",1000000.00);
		System.out.println(banktransaction);
		int a = in.nextInt();
		switch(a) {
			case 1 :
				banktransaction.withdraw(in.nextDouble());
				break;
			case 2 :
				banktransaction.deposit(in.nextDouble());
				break;
			case 3 :
				banktransaction.balanceEnquiry();
				break;
		}
		System.out.println(banktransaction);

	}
}