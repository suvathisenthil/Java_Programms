package com;
import java.util.Scanner;
public class Solution {
	public static void main(String args[]) {
		Time t = null;
		Scanner in = new Scanner(System.in);
		int a,b;
		a=in.nextInt();
		switch(a) {
			case 1: 
				t = new Time();
				break;
			case 2: 
				t = new Time(in.nextInt());
				break;
			case 3: 
				t = new Time(in.nextInt(), in.nextInt());
				break;
			case 4: 
				t = new Time(in.nextInt(), in.nextInt(), in.nextInt());
				break;
			}
		b = in.nextInt();
		switch(b) {
			case 1: 
				Time t2 = t.nextSecond();
				System.out.println(t2);
				break;
			case 2: 
				Time t3 = t.nextMinute();
				System.out.println(t3);
				break;
			case 3: 
				Time t4 = t.nextHour();
				System.out.println(t4);
				break;
			case 4: 
				Time t5 = t.previousSecond();
				System.out.println(t5);
				break;
			case 5: 
				Time t6 = t.previousMinute();
				System.out.println(t6);
				break;
			case 6: 
				Time t7 = t.previousHour();
				System.out.println(t7);
				break;
		}
	}
}

