package com;
public class Time {
	int hour;
	int minute;
	int second;
	public Time () {
		this(0, 0, 0);
	}
	public Time (int hour) {
		this(hour, 0, 0);
	}
	public Time (int hour,int minute) {
		this(hour, minute, 0);
	}
	
	public Time (int hour,int minute,int second) {
		this.hour = hour;
		this.minute = minute;
		this.second = second;
	}

	 Time nextSecond() {
	 	int remainder,hh,mm,ss;
        remainder = (this.second + 1) / 60;
        ss = (this.second + 1) % 60;
        remainder = (remainder + this.minute) / 60;
        mm = (remainder + this.minute) % 60;
        hh = (this.hour + remainder) % 24;
        Time out = new Time(hh,mm,ss);
        return out;
    }
	Time nextMinute() {
		int remainder,hh,mm,ss;
        remainder = (this.second) / 60;
        ss = (this.second) % 60;
        remainder = (remainder + this.minute + 1 ) / 60;
        mm = (remainder + this.minute + 1) % 60;
        hh = (this.hour + remainder) % 24;
        Time out1 = new Time(hh,mm,ss);
        return out1;
	}
	Time nextHour() {
		int remainder,hh,mm,ss;
        remainder = (this.second) / 60;
        ss = (this.second ) % 60;
        remainder = (remainder + this.minute) / 60;
        mm = (remainder + this.minute) % 60;
        hh = (this.hour + remainder + 1) % 24;
        Time out2 = new Time(hh,mm,ss);
        return out2;
	}
	Time previousSecond() {
		int hh = this.hour,mm = this.minute,ss = this.second;
		if (this.second == 0) {
			ss = 59;
			if (this.minute == 0){
				mm =59;
				if( this.hour == 00) {
					hh = 23;
				}
			}
		}
		else {
			ss = this.second - 1;
		}
        Time out3 = new Time(hh,mm,ss);
        return out3;
	}
	Time previousMinute() {
		int hh = this.hour,mm = this.minute,ss = this.second;
		if (this.minute == 0){
				mm =59;
			}
		else {
			mm = this.minute - 1;
		}
        Time out4 = new Time(hh,mm,ss);
        return out4;
	}
	Time previousHour() {
		int hh = this.hour,mm = this.minute,ss = this.second;
		if( this.hour == 00) {
					hh = 23;
				}
		else {
			hh = this.hour - 1;
		}
        
        Time out5 = new Time(hh,mm,ss);
        return out5;
	}
	public String toString() {
		return String.format("%02d:%02d:%02d",this.hour,this.minute,this.second);
	}
}