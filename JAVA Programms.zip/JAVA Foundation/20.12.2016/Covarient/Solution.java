package org.main;
import java.util.Scanner;
public class Solution {
	public static void main(String args[]) {
		Complex c1 = new Complex(10, 20);
		Complex c2 = new Complex(20, 30);
		Scanner in = new Scanner(System.in);
		int a;
		a=in.nextInt();
		switch(a) {
			case 1:
				System.out.println(c1+" -->"+c1.add(-5,-7));
				break;
			case 2:
				System.out.println(c1+" -->"+c1.subtract(10,20));
				break;
			case 3:
				System.out.println(c1+" -->"+c1.multiplyWith(2,3));
				break;
			case 4:
				System.out.println(c1+" -->"+c1.divideBy(3,3));
				break;
			case 5:
				System.out.println(c1+" -->"+c2+"-->"+c1.add(c2));
				break;
			case 6:
				System.out.println(c1+" -->"+c2+"-->"+c1.subtract(c2));
				break;
			case 7:
				System.out.println(c1+" -->"+c2+"-->"+c1.multiplyWith(c2));
				break;
			case 8:
				System.out.println(c1+" -->"+c2+"-->"+c1.divideBy(c2));
				break;

		}
	}
}