public class Complex {
	public Complex() {
		real = 0;
		imaginary = 0;
	}
	public Complex(int real,int imaginary) {
		this.real = real;
		this.imaginary = imaginary;
	}

	int real = 0;
	int imaginary = 0;
	public String toString() {
		return this.real+(this.imaginary > -1?"+":"")+this.imaginary+"j";
	}
	void set(int real,int imaginary) {
		this.real = real;
		this.imaginary = imaginary;
	}
	public boolean isReal() {
		if(real != 0) {
			return true;
		}
		else
			return false;
	}
	public boolean isImaginary() {
		if(real == 0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public Complex add(int real, int imaginary) {
		int result1 = (real + this.real);
		int result2 = (imaginary + this.imaginary);
		Complex com1 = new Complex(result1,result2);
		return com1;
	}
	public Complex subtract(int real, int imaginary) {
		int result1 = (this.real  - real);
		int result2 = (this.imaginary - imaginary);
		Complex com2 = new Complex(result1,result2);
		return com2;
	}
	public Complex multiplyWith(int real, int imaginary) {
		int result1 = (real * this.real);
		int result2 = (imaginary * this.imaginary);
		Complex com3 = new Complex(result1,result2);
		return com3;
	}
	public Complex divideBy(int real, int imaginary) {
		int result1 = (this.real / real );
		int result2 = (this.imaginary / imaginary );
		Complex com3 = new Complex(result1,result2);
		return com3;
	}
	public Complex add(Complex another) {
		int result1 = (another.real + this.real);
		int result2 = (another.imaginary + this.imaginary);
		Complex comp1 = new Complex(result1,result2);
		return comp1;
	}
	public Complex subtract(Complex another) {
		int result1 = (this.real - another.real);
		int result2 = (this.imaginary - another.imaginary);
		Complex comp2 = new Complex(result1,result2);
		return comp2;
	}
	public Complex multiplyWith(Complex another) {
		int result1 = (this.real * another.real);
		int result2 = (this.imaginary * another.imaginary);
		Complex comp3 = new Complex(result1,result2);
		return comp3;
	}
	public Complex divideBy(Complex another) {
		int result1 = (this.real / another.real);
		int result2 = (this.imaginary / another.imaginary);
		Complex comp4 = new Complex(result1,result2);
		return comp4;
	}
}