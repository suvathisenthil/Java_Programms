package org;

import com.shape.Shape;
import com.shape.round.Circle;
import com.shape.round.Cylinder;
import com.shape.sqr.Rectangle;
import com.shape.tri.Triangle;

public class Solution {
	public static void main(String args[]) {
		Circle cic = new Circle("Yellow", 12.5);
		System.out.println(cic.area());
		System.out.println(cic.getColor());
		Cylinder c = new Cylinder(cic.getColor(), 25, 12);
		System.out.println(c.area());
		System.out.println(c.getColor());
		Rectangle rectangle = new Rectangle("white",2.5,5.5);
		System.out.println(rectangle.area());
		System.out.println(rectangle.getColor());
		Triangle triangle = new Triangle("grey", 4.5, 5.58);
		System.out.println(triangle.area());
		System.out.println(triangle.getColor());
	}
}