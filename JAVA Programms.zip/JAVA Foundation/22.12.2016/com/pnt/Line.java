package com.pnt;

public class Line extends Point {
	private int x = 0;
	private int y = 0;
	public Line() {
		super();
	}
	public Line(int axis) {
		super(axis);
	}

	public Line(int axis, int xs, int ys) {
		super(axis);
		this.x = xs;
		this.y = ys;		
	}
	public Line(int xs, int ys) {
		super();
		this.x = xs;
		this.y = ys;		
	}
	public Line(int xs, int ys, int x, int y) {
		super(x, y);
		this.x = xs;
		this.y = ys;		
	}
	
	public double distance() {
		double ac = Math.pow((this.x + super.x), 2);
		double bc = Math.pow((this.y + super.y), 2);
		double result = Math.sqrt(ac + bc);
		return result;
	}
	public String toString() {
		return "("+super.x + "," +super.y + ").........................("+this.x + "," + this.y + ")";
	}
	

}
