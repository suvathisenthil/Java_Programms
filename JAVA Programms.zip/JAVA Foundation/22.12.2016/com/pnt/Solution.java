package com.pnt;

import java.util.Scanner;

public class Solution {

	public static void main(String[] args) {
		Line line = null;
		Scanner in = new Scanner(System.in);
		int a;
		a=in.nextInt();
		switch(a) {
			case 1:
				line = new Line();
				break;
			case 2:
				line = new Line(in.nextInt());
				break;
			case 3:
				line = new Line(in.nextInt(), in.nextInt(),in.nextInt());
				break;
			case 4:
				line = new Line(in.nextInt(), in.nextInt());
				break;
			case 5:
				line = new Line(in.nextInt(), in.nextInt(), in.nextInt(), in.nextInt());
				break;
		}
		System.out.println(line.distance());
		System.out.println(line);

	}

}
