package com.shape.sqr;

import com.shape.Shape;

public class Rectangle extends Shape {
	private double length ;
	private double breadth;
	public Rectangle() {
		super();
		this.length = 1;
		this.breadth = 1;
	}
	public double getLength() {
		return length;
	}
	public void setLength(double length) {
		this.length = length;
	}
	public double getBreadth() {
		return breadth;
	}
	public void setBreadth(double breadth) {
		this.breadth = breadth;
	}
	public Rectangle(String color,double length, double breadth) {
		super(color);
		this.length = length;
		this.breadth = breadth;
	}
	public double area() {
		return this.breadth * this.length;
	}
	
	

}
