package com.shape.tri;

import com.shape.Shape;

public class Triangle extends Shape {
	private double base;
	private double height;
	final protected static double HALF = 0.5;
	public Triangle() {
		super();
	}
	public double getBase() {
		return base;
	}
	public void setBase(double base) {
		this.base = base;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public Triangle(String color,double base, double height) {
		super(color);
		this.base = base;
		this.height = height;
	}
	public double area () {
		return this.base * this.height * Triangle.HALF;
		
	}
	
	

}
