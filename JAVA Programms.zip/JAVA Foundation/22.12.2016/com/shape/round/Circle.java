package com.shape.round;

import com.shape.Shape;

public class Circle extends Shape {
	protected double radius;
	final protected static double PI = 3.14;
	public Circle() {
		super();
		this.radius = 1;
	}
	public double getRadius() {
		return radius;
	}
	public Circle(String color,double radius) {
		super(color);
		this.radius = radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
	public double area () {
		return this.radius * this.radius * Circle.PI;
		
	}

}
