package com.wirpo;

public class Users {
	private String username;
	private String password;
	private int transactionPin;
	private boolean admin;
	
	public Users() {
		super();
	}

	public Users(String username, String password, int transactionPin, boolean admin) {
		super();
		this.username = username;
		this.password = password;
		this.transactionPin = transactionPin;
		this.admin = admin;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getTransactionPin() {
		return transactionPin;
	}

	public void setTransactionPin(int transactionPin) {
		this.transactionPin = transactionPin;
	}

	public boolean isAdmin() {
		return admin;
	}

	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	@Override
	public String toString() {
		return "Users [username=" + username + ", password=" + password + ", transactionPin=" + transactionPin
				+ ", admin=" + admin + "]";
	}
	
	

}
