package org;

import com.shape.round.Circle;
import com.shape.sqr.Rectangle;
import com.shape.sqr.Square;

public class Solution {
	public static void main(String[] args) {
		Circle c = new Circle(5);
		System.out.println(c);
		System.out.println("Area of circle :"+c.getArea());
		Rectangle r = new Rectangle("PINK",false,22,12);
		System.out.println(r);
		System.out.println("Area of Rectangle :"+r.getArea());
		Square s = new Square(5, "YELLOW", true);
		System.out.println(s);
		System.out.println("Area of Square :"+s.getArea());
		System.out.println("Perimeter of square :"+s.getPerimeter());
	}
}