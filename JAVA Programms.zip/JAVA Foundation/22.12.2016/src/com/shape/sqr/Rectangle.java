package com.shape.sqr;

import com.shape.Shape;

public class Rectangle extends Shape {
	private double length ;
	private double width;
	public Rectangle() {
		super();
		this.length = 1;
		this.width = 1;
	}
	public double getLength() {
		return length;
	}
	public void setLength(double length) {
		this.length = length;
	}
	public double getwidth() {
		return width;
	}
	public void setwidth(double width) {
		this.width = width;
	}
	public Rectangle(double length, double width) {
		super();
		this.length = length;
		this.width = width;		
	}
	public Rectangle(String color,boolean filled,double length, double width) {
		super(color,filled);
		this.length = length;
		this.width = width;
	}
	public double getArea() {
		return this.width * this.length;
	}
	public double getPerimeter () {
		return 2 * (this.length + this.width);
		
	}
	@Override
	public String toString() {
		return super.toString()+"Rectangle [length=" + length + ", width=" + width + "]";
	}
}
