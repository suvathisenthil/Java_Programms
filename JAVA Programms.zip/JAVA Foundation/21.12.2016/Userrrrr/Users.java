public Users {
	private String username;
	private String password;
	private int transactionPin;
	private boolean admin;
	public  String getUsername () {
		return this.username;
	}
	public void setUsername (String username) {
		this.username = username;
	}
	public  String getPassword () {
		return this.password;
	}
	public void setPassword (String password) {
		this.password = password;
	}
	public  int getTransactionPin () {
		return this.transactionPin;
	}
	public void setTransactionPin (int transactionPin) {
		this.transactionPin = transactionPin;
	}
	public  boolean isAdmin () {
		return this.admin;
	}
	public void setAdmin (boolean admin) {
		this.admin = admin;
	}
	public Users (String username,String password,int transactionPin,boolean admin) {
		this.username = username;
		this.password = password;
		this.transactionPin =transactionPin;
		this.admin = admin;
	}
	public String toString() {
		return String.format("%-20s : ","USERNAME")+this.username+String.format("\n%-20s : ","PASSWORD")+this.password+String.format("\n%-20s : ","TRANSACTION PIN")+String.format("%04d",this.transactionPin)+String.format("\n%-20s : ","ADMIN")+this.admin;
	}
}