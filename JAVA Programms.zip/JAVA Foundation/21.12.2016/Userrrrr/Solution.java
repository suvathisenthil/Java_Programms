public class Solution {
	public static void main(String args[]) {
		Users u = new Users("Swathi" ,"12345",5678,true);
		System.out.println(u);
	}
}