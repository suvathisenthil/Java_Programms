public class Time {
	int hour;
	int minute;
	int second;
	public Time () {
		this(0, 0, 0);
		this.print();

	}
	public Time (int hour) {
		this(hour, 0, 0);
		this.print();

	}
	public Time (int hour,int minute) {
		this(hour, minute, 0);
		this.print();

	}
	public Time (int hour,int minute,int second) {
		this.hour = hour;
		this.minute = minute;
		this.second = second;
		this.print();

	}

	void nextSecond() {
		int remainder = 0;
		this.second +=1;
		remainder = this.second/60;
		this.second %= 60;
		this.minute += remainder;
		remainder = this.minute/60;
		this.minute %=60;
		this.hour = (this.hour + remainder)%24;
		this.print();
	}

	void print() {
		System.out.println(String.format("%02d:%02d:%02d",this.hour,this.minute,this.second));
	}
}