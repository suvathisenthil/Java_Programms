import java.util.Scanner;
public class Solution {
	public static void main(String args[]) {
		Time t = new Time(23,59,59);
		t.nextSecond();
		t.print();

	}
}
