public class Employee {
	String identity = "";
	String name = "";
	String designation = "";
	double salary = 0; 
	public Employee (String identity, String name,String designation, double salary ){
		this.identity = identity;
		this.designation = designation;
		this.name = name;
		this.salary = salary;
	}
	public String toString() {
		return String.format("%-20s : ","IDENTITY")+this.identity+String.format("\n%-20s : ","NAME")+this.name+String.format("\n%-20s : ","DESIGNATION")+this.designation+String.format("\n%-20s : Rs.","SALARY")+String.format("%.2f",this.salary);
	}
}