public class Solution {
	public static void main(String args[]) {
		Employee e = new Employee("APP001","Steve Jobs","Owner",10000.0);
		System.out.println(e);
	}
}