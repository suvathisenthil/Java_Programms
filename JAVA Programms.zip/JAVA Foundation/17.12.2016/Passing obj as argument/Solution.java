import java.util.Scanner;
public class Solution {
	public static void main(String args[]) {
		Point p = new Point(5,10);
		Point p1 = new Point(15,20);
		Scanner in = new Scanner(System.in);
		System.out.println(p+" --> "+p1+"="+String.format("%.2f",p.distance(p1)));
		p.setXY(10,20);
		p.print();
	}

}