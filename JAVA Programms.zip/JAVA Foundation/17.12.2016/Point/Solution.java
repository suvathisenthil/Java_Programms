package com.wipro;
import java.util.Scanner;
public class Solution {
	public static void main(String args[]) {
		Point p = new Point(5,10);
		Scanner in = new Scanner(System.in);
		System.out.println(p.distance(5,10));
		p.setXY(10,20);
		p.print();
	}

}