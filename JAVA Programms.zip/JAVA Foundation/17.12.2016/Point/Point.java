package com.wipro;
public class Point {
	int x = 0;
	int y = 0;
	public Point() {
		this(0, 0);
	}
	public Point(int axis) {
		this(axis, axis);
	}
	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}
	void setXY(int x,int y) {
		this.x = x;
		this.y = y;
	}
	double distance() {
		return this.distance(0,0);
	}
	double distance(int axis) {
		return this.distance(axis,axis);		

	}
	double distance(int x,int y) {
		double ac = Math.pow((this.x + x), 2);
		double bc = Math.pow((this.y + y), 2);
		return Math.sqrt(ac + bc);
	}
	void print() {
		System.out.println(this.x+"  "+this.y);
	}

}