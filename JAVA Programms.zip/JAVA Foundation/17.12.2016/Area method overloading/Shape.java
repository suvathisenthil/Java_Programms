public class Shape {
	void area(double radius) {
		System.out.println("Area of circle :"+(radius*radius*3.14));
	}
	void area(int side) {
		System.out.println("Area of square :"+(4*side));
	}
	void area(double length, double breadth) {
		System.out.println("Area of rectangle :"+(length*breadth));
	}

}