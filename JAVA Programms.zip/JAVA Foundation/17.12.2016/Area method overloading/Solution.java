import java.util.Scanner;
public class Solution {
	public static void main(String args[]) {
		Shape s = new Shape();
		s.area(4.56);
		s.area(5);
		s.area(3.15,3.65);

	}
}