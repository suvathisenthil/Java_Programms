import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
public class ThreeDimension {
	public static void main (String args[]) throws FileNotFoundException {
		int arr[][][];
		Scanner in = new Scanner(new File("InputLeap.txt"));
		arr = new int[12][][];
		int month[]={31,28,31,30,31,30,31,31,30,31,30,31};
		System.out.println("Enter array elements :");
		for(int i = 0; i < month.length; i++) {
			arr[i] = new int [month[i]][24];
		}
		for(int i = 0; i < arr.length; i++) {
			for(int j = 0; j < arr[i].length; j++) {
				for(int k = 0; k < arr[i][j].length; k++) {
					arr[i][j][k] = in.nextInt();
				}
			}

		}
		System.out.println("The array elements are :");
		for(int i = 0; i < arr.length; i++) {
			for(int j = 0; j < arr[i].length; j++) {
				for(int k = 0; k < arr[i][j].length; k++) {
					System.out.println("arr["+i+"]["+j+"]["+k+"]  :"+arr[i][j][k]);
				}
			}

		}
		in = new Scanner(System.in);
		int choice,mon,date,sum = 0,avg = 0;
		System.out.println("Enter your choice :");
		choice = in.nextInt();
		switch(choice) {
			case 1:
				System.out.println("Enter month and date :");
				mon = in.nextInt();
				date = in.nextInt();
				for(int k = 0;k < arr[mon-1][date-1].length; k++) {
					sum = sum + arr[mon-1][date-1][k];

				}
				avg = sum/arr[mon-1][date-1].length;
				System.out.println("Average number of viewers on a particular day "+avg);
				break;
			case 2:
				System.out.println("Enter month and date :");
				mon = in.nextInt();
				date = in.nextInt();
				for(int k = 0;k < arr[mon-1][date-1].length; k++) {
					sum = sum + arr[mon-1][date-1][k];

				}
				avg = sum/arr[mon-1][date-1].length;
				System.out.println("Total number of viewers on a particular day "+sum);
				System.out.println("Average number of viewers on a particular day "+avg);
				break;
			case 3:
				System.out.println("Enter month");
				mon = in.nextInt();
				int lastDate = 0;
				for(int i = 0;i < arr[mon-1].length; i++) {
					for(int j = 0;j < arr[mon-1][i].length; j++) {
						sum = sum + arr[mon-1][i][j];						
					}
					avg = avg + ((sum)/arr[mon-1][i].length);
					lastDate = i;
				}
				System.out.println("Total number of viewers on a particular month "+sum);
				System.out.println("Average number of viewers on a particular month per day "+(avg/lastDate));
				break;
			case 4:
				System.out.println("Enter day");
				date = in.nextInt();
				for(int i = 0;i < arr.length; i++) {
					sum = 0;
					for(int j = 0;j < arr[i][date-1].length; j++) {
						sum = sum + arr[i][date-1][j];
					}
						System.out.println("Total number of viewers on "+(i+1)+" month on "+date+" day is :"+sum);
						System.out.println("Average number of viewers on "+(i+1)+" month on "+date+" day is :"+sum/(arr[i][date-1].length));
				}
				break;
			case 5:
				System.out.println("Enter month");
				mon = in.nextInt();
				for(int i = 0;i < arr[mon-1].length; i++) {
					sum = 0;
					for(int j = 0;j < arr[mon-1][i].length; j++) {
						sum = sum + arr[mon-1][i][j];
					}
						System.out.println("Total number of viewers on "+(mon)+" nth month on "+(i+1)+"th day is :"+sum);
						System.out.println("Average number of viewers on "+(mon)+" nth month on "+(i+1)+"th day is :"+sum/(arr[mon-1][i].length));
				}
				break;
			case 6:
				System.out.println("Enter month");
				mon = in.nextInt();
				System.out.println("Enter range");
				int range = 0;
				range = in.nextInt();
				for(int i = (range-1);i < arr[mon-1].length; ) {
					sum = 0;
					for(int j = 0;j < arr[mon-1][i].length; j++) {
						sum = sum + arr[mon-1][i][j];
					}
						System.out.println("Total number of viewers on "+(mon)+" nth month on "+(i+1)+"th day is :"+sum);
						System.out.println("Average number of viewers on "+(mon)+" nth month on "+(i+1)+"th day is :"+sum/(arr[mon-1][i].length));
						i = i + range;
				}
				break;
			case 7:
				System.out.println("Enter start month");
				int smon;
				smon = in.nextInt();
				System.out.println("Enter end month");
				int emon;
				emon = in.nextInt();
				System.out.println("Enter range");
				range = in.nextInt();
				for(int k = smon-1; k < emon ; k++) {
					for(int i = (range-1);i < arr[k].length; ) {
						sum = 0;
						for(int j = 0;j < arr[k][i].length; j++) {
							sum = sum + arr[k][i][j];
						}
							System.out.println("Total number of viewers on "+(k+1)+" nth month on "+(i+1)+"th day is :"+sum);
							System.out.println("Average number of viewers on "+(k+1)+" nth month on "+(i+1)+"th day is :"+sum/(arr[k][i].length));
							i = i + range;
					}
				}
				break;
			case 8:
				System.out.println("Enter month");
				mon = in.nextInt();
				System.out.println("Enter month range");
				range = in.nextInt();
				for(int k = mon-1; k < arr.length ; ) {
					for(int i = 0;i < arr[k].length;i++ ) {
						sum = 0;
						for(int j = 0;j < arr[k][i].length; j++) {
							sum = sum + arr[k][i][j];
						}
							System.out.println("Total number of viewers on "+(k+1)+" nth month on "+(i+1)+"th day is :"+sum);
							System.out.println("Average number of viewers on "+(k+1)+" nth month on "+(i+1)+"th day is :"+sum/(arr[mon-1][i].length));
							
					}
					k = k + range;
				}
					break;


		}
		

	}
}