package com.book.dao;

public class Author {
	private String identity, name, email, gender, phoneNo;
	private Book book[];
	
	public Book[] getBook() {
		return book;
	}
	public void setBook(Book[] book) {
		this.book = book;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public Author(String identity, String name, String email, String gender, String phoneNo, Book[] book) {
		super();
		this.identity = identity;
		this.name = name;
		this.email = email;
		this.gender = gender;
		this.phoneNo = phoneNo;
		this.book = book;
	}
	public Author(String identity, String name, String email, String gender, String phoneNo) {
		super();
		this.identity = identity;
		this.name = name;
		this.email = email;
		this.gender = gender;
		this.phoneNo = phoneNo;
	}
	public String getIdentity() {
		return identity;
	}
	public void setIdentity(String identity) {
		this.identity = identity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	@Override
	public String toString() {
		String temp = "";
		for(Book each:book) {
			temp += each;
		}
		return "Author [identity=" + identity + ", name=" + name + ", email=" + email + ", gender=" + gender
				+ ", phoneNo=" + phoneNo + ", book=" + temp + "]";
	}
}
