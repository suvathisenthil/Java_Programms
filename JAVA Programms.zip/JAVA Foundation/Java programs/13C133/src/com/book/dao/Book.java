package com.book.dao;

import java.util.Arrays;

public class Book {
	private String ISBN, name;
	private double price;
	private int qtyInStock = 0;
	private Author author[];
	
	public Book(String iSBN, String name, double price, int qtyInStock, Author[] author) {
		super();
		ISBN = iSBN;
		this.name = name;
		this.price = price;
		this.qtyInStock = qtyInStock;
		this.author = author;
	}
	public Book(String iSBN, String name, double price, int qtyInStock) {
		super();
		ISBN = iSBN;
		this.name = name;
		this.price = price;
		this.qtyInStock = qtyInStock;
	}
	public Author[] getAuthor() {
		return author;
	}
	public void setAuthor(Author author[]) {
		this.author = author;
	}
	public String getISBN() {
		return ISBN;
	}
	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQtyInStock() {
		return qtyInStock;
	}
	public void setQtyInStock(int qtyInStock) {
		this.qtyInStock = qtyInStock;
	}
	@Override
	public String toString() {
		return "Book [ISBN=" + ISBN + ", name=" + name + ", price=" + price + ", qtyInStock=" + qtyInStock + ", author="
				+ Arrays.toString(author) + "]";
	}
	
	

}
