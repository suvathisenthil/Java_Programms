package com.book.org;

import java.util.Scanner;

import com.book.dao.Author;
import com.book.dao.Book;

public class Solution {
	public static void main(String[] args) {
		
		Book boo[];  		
		boo = new Book [2];
		boo [0]= new Book("AAA", "Steve", 125.25, 2);
		boo [1]= new Book("BBB", "Gupta", 200.25, 5);
		Author author = new Author("AA001", "Jobs", "dss@fgg", "M", "99596559",boo);
		System.out.println(boo[0]);
		System.out.println(author);	
		
	}
}
