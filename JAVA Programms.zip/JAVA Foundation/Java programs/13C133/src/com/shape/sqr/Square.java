package com.shape.sqr;

public class Square extends Rectangle {
	private double side;
	public Square() {
		super();
	}
	public Square(double side) {
		super(side,side);
	}
	public Square(double side, String color, boolean filled) {
		super(color,filled,side,side);
	
	}
	public double getSide() {
		return super.getLength();
	}
	public void setSide(double side) {
		super.setLength(side);
	}
	public void setWidth(double side) {
		super.setwidth(side);
	}
	public void setLength(double side) {
		super.setwidth(side);
	}
	@Override
	public String toString() {
		return super.toString()+"Square [side=" + side + ", getSide()=" + getSide() + ", getLength()=" + getLength() + ", getwidth()="
				+ getwidth() + ", getArea()=" + getArea() + ", getPerimeter()=" + getPerimeter() + ", isFilled()=" + isFilled() + ", getColor()=" + getColor() + "]";
	}
}