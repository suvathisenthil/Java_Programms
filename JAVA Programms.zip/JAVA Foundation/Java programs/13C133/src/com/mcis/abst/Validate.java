package com.mcis.abst;

public class Validate extends Account {

	@Override
	public boolean getValidateInfo() {
		System.out.println("Login Success");
		return false;
	}
	
}
