package com.mcis.util;

import com.mcis.intf.Utility;
import com.mcis.intf.InfoValidate;
import com.mcis.intf.Input;
import com.mcis.intf.Test;

public class Solution {

	public static void main(String[] args) {
		Test info = new InfoValidate();
		info.area();
		info.perimeter();
		info.getInfo();
		Input info1 = new InfoValidate();
		Utility info2 = new InfoValidate();
		
	}

}








