package com.mcis.intf;

public class InfoValidate extends Test {

	@Override
	public double area() {
		return 0;
	}

	@Override
	public void perimeter() {
	}

	@Override
	public void getInfo() {
	}

}
