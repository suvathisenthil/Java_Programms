package com.mcis.intf;

public interface Input extends Utility {
	public double PI = 3.14;
	public double area();
}
