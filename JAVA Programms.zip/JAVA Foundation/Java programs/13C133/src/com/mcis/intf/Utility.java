package com.mcis.intf;

public interface Utility {
	public double HALF = 0.5;
	public void perimeter();
}
