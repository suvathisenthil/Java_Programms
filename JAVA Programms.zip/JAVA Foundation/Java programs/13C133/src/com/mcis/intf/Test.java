package com.mcis.intf;

public abstract class Test implements Input {
	public abstract void getInfo();
}
