package com.mcis.coll;

import java.util.Comparator;

import com.mcis.asso.dao.Employee;

public class DesignationAscending implements Comparator<Employee> {

	@Override
	public int compare(Employee o1, Employee o2) {
		return o1.getDesignation().compareTo(o2.getDesignation());
	}

}
