package com.mcis.coll;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import com.mcis.asso.dao.Employee;

public class Solution {
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		Set<Employee> list = null;
		switch(in.nextInt()) {
			case 1:
				list = new TreeSet<Employee>(new IdentityAscending());
				break;
			case 2:
				list = new TreeSet<Employee>(new IdentityDescending());
				break;
			case 3:
				list = new TreeSet<Employee>(new DesignationAscending());
				break;
			case 4:
				list = new TreeSet<Employee>(new DesignationDescending());
				break;
			case 5:
				list = new TreeSet<Employee>(new NameAscending());
				break;
			case 6:
				list = new TreeSet<Employee>(new NameDescending());
				break;
			case 7:
				list = new TreeSet<Employee>(new SalaryAscending());
				break;
			case 8:
				list = new TreeSet<Employee>(new SalaryDescending());
				break;			
		}
		list.add(new Employee("AP001","Steve","CEO - Apple",1200000.00));
		list.add(new Employee("AP002","Guido","CEO - Python.org",12000.00));
		list.add(new Employee("AP005","Steve","CEO - Apple",1200000.00));
		list.add(new Employee("AP003","James","Developer",12000.00));
		list.add(new Employee("AP006","Steve","CEO - Apple",1200000.00));
		list.add(new Employee("AP004","EdFrank","Senior Developer",120000.00));
		list.add(new Employee("AP007","Steve","CEO - Apple",1200000.00));
		System.out.println(list);
	}
}
