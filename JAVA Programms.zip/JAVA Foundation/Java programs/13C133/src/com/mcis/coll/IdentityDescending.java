package com.mcis.coll;

import java.util.Comparator;

import com.mcis.asso.dao.Employee;

public class IdentityDescending implements Comparator<Employee> {

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		return o2.getIdentity().compareTo(o1.getIdentity());
	}

}
