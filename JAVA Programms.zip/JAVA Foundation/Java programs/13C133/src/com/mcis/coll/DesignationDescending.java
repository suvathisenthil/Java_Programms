package com.mcis.coll;

import java.util.Comparator;

import com.mcis.asso.dao.Employee;

public class DesignationDescending implements Comparator<Employee> {

	@Override
	public int compare(Employee o1, Employee o2) {
		return o2.getDesignation().compareTo(o1.getDesignation());
	}

}
