package com.mcis.coll;

import java.util.Comparator;

import com.mcis.asso.dao.Employee;

public class IdentityAscending implements Comparator<Employee> {

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		return o1.getIdentity().compareTo(o2.getIdentity());
	}

}