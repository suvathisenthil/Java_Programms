package com.mcis.asso.dao;

public class Employee {
	private String identity, name, designation;
	private double salary;
	
	public Employee(String identity, String name, String designation, double salary) {
		super();
		this.identity = identity;
		this.name = name;
		this.designation = designation;
		this.salary = salary;
	}
	public String getIdentity() {
		return identity;
	}
	public void setIdentity(String identity) {
		this.identity = identity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "\n\tEmployee [identity=" + identity + ", name=" + name + ", designation=" + designation + ", salary="
				+ salary + "]";
	}
}
