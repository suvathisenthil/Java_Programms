package com.dbmsconn;

public class Contactt {
		private String firstName,lastName,emailId;
		private long phoneNo;
		

		public Contactt() {
			super();
		}

		public Contactt(String firstName, String lastName, long phoneNo, String emailId) {
			super();
			this.firstName = firstName;
			this.lastName = lastName;
			this.phoneNo = phoneNo;
			this.emailId = emailId;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public long getPhoneNo() {
			return phoneNo;
		}

		public void setPhoneNo(long l) {
			this.phoneNo = l;
		}

		public String getEmailId() {
			return emailId;
		}

		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}

		@Override
		public String toString() {
			return "Contactt [firstName=" + firstName + ", lastName=" + lastName + ", emailId=" + emailId + ", phoneNo="
					+ phoneNo + "]\n";
		}

		
	}
