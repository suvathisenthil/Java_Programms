package com.dbmsconn;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

public class Solu {
	public static void main(String[] args) throws IOException {
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver Loaded");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "oracle");
			System.out.println("Connection created");
			ps = connection.prepareStatement("update contact set lastname = ? where lastname = ?");
			ps.setString(1, "Senthil Kumar");
			ps.setString(2, "senthil");
			ps.executeUpdate();
			ps = connection.prepareStatement("select * from contact");
			ResultSet rs = ps.executeQuery();
			List<Contactt> list = new LinkedList<Contactt>();
			Contactt c = null;
			while(rs.next()) {
				c = new Contactt();
				c.setEmailId(rs.getString(4));
				c.setFirstName(rs.getString(1));
				c.setLastName(rs.getString(2));
				c.setPhoneNo(rs.getLong(3));
				list.add(c);
			}
			System.out.println(list);
			ps.close();
			connection.close();
			}catch(Exception e) {
				e.printStackTrace();				
			}
		System.out.println("out");

}
	}