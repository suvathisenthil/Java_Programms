 package com.dbmsconn;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Solution {

	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver Loaded");
			Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "oracle");
			System.out.println("Connection created");
			Statement statement = connection.createStatement();
			System.out.println("Statement Created");
			String query = "select * from employee";
			ResultSet rs = statement.executeQuery(query);
			while(rs.next()) {
				System.out.println(rs.getString("identity"));
			}
			/*int count = statement.executeUpdate(query);
			System.out.println(count+" Affected");
	 		String query = "create table employee(identity varchar2(20), Name varchar2(20),designation varchar(20),salary number(20, 2))";
			"insert into employee values('AP001', 'Steve Jobs','CEO',120000.00)"
			boolean status = statement.execute(query);
			if(!status) {
				System.out.println("Table created");
			}*/
			statement.close();
			connection.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
