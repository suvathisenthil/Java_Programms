package com.dbmsconn;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Contact {

	public static void main(String[] args) throws IOException {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver Loaded");
			Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "oracle");
			System.out.println("Connection created");
			Statement statement = connection.createStatement();
			System.out.println("Statement Created");
			/*String query = "create table contact(firstname varchar2(20), lastname varchar2(20),phonenumber number(20),email varchar(20))";
			statement.executeQuery(query);	*/
			ResultSet rs;
			BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
			switch (Integer.valueOf(bf.readLine())) {
			case 1:
				String name = bf.readLine();
				String que = "update contact set firstname = '"+name+"' ";
				statement.execute(que);
				System.out.println("update successful");
				break;
				
			case 2:
				String fname = bf.readLine();
				String lname = bf.readLine();
				long no = Long.valueOf(bf.readLine());
				String mail = bf.readLine();
				String qu = "insert into contact values('"+fname+"','"+lname+"','"+no+"','"+mail+"')";
				statement.execute(qu);
				System.out.println("Insert successful");

				break;
				
			case 3:
				String name1 = bf.readLine();
				String q = "delete from contact where firstname ='"+name1+"'";
				statement.execute(q);
				System.out.println("Delete successful");
				break;
			
			case 4:
				String quer = "select * from contact";
				rs = statement.executeQuery(quer);
				while(rs.next()) {
					System.out.println(rs.getString(1));
					System.out.println(rs.getString(2));
					System.out.println(rs.getLong(3));
					System.out.println(rs.getString(4));
				}
				rs.close();
				break;
				
			case 5:
				long ph = Long.valueOf(bf.readLine());
				String q1 = "select * from contact where phonenumber='"+ph+"'";
				rs = statement.executeQuery(q1);
				while(rs.next()) {
					System.out.println(rs.getString(1));
					System.out.println(rs.getString(2));
					System.out.println(rs.getLong(3));
					System.out.println(rs.getString(4));
				}
				rs.close();
				break;
			}
			statement.close();
			connection.close();			
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		}catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
