package com.coll;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Solution {

	public static void main(String[] args) {
		List <String> list = new ArrayList<String>();
		list.add("swathi");
		list.add("sona");
		System.out.println(list.size());
		System.out.println(list.isEmpty());
		System.out.println(list.contains("Swa"));
		//System.out.println(list.add("senthil"));
		System.out.println(list);
		List <String> list1 = new ArrayList<String>();
		list1.add("swathi");
		list1.add("sona");
		System.out.println(list1);
		//System.out.println(list.addAll(list1));
		System.out.println(list.equals(list1));
		System.out.println(list.indexOf("swathi"));
		System.out.println(list);
		Iterator<String> iterator = list.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		List l2 = list.subList(0, 1);
		System.out.println(l2);
	}
}
