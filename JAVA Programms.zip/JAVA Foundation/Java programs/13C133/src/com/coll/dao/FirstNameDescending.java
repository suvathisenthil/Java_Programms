package com.coll.dao;

import java.util.Comparator;

public class FirstNameDescending implements Comparator<Contact>{

	@Override
	public int compare(Contact o1, Contact o2) {
		return o2.getFirstName().compareTo(o1.getFirstName());
	}
	

}
