package com.coll.dao;

public class Contact {
	private String firstName,lastName,phoneNo,emailId;

	public Contact(String firstName, String lastName, String phoneNo, String emailId) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNo = phoneNo;
		this.emailId = emailId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Override
	public String toString() {
		if(this.phoneNo.startsWith("+91"))
			return String.format("\n%-30s",this.firstName)+String.format("%-30s",this.lastName)+String.format("%-30s",this.phoneNo)+String.format("%2s@gamil.com",this.emailId);
		else if(this.emailId.endsWith("@gamil.com"))
			return String.format("\n%-30s",this.firstName)+String.format("%-30s",this.lastName)+String.format("+91%-27s",this.phoneNo)+String.format("%s",this.emailId);
		else if(this.phoneNo.startsWith("+91") && this.emailId.endsWith("@gamil.com"))
			return String.format("\n%-30s",this.firstName)+String.format("%-30s",this.lastName)+String.format("%-30s",this.phoneNo)+String.format("%s",this.emailId);
		else
			return String.format("\n%-30s",this.firstName)+String.format("%-30s",this.lastName)+String.format("+91%-27s",this.phoneNo)+String.format("%s@gamil.com",this.emailId);
	}
}
