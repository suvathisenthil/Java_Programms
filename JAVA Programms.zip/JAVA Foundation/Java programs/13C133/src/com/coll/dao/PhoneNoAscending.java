package com.coll.dao;

import java.util.Comparator;

public class PhoneNoAscending implements Comparator<Contact>{

	@Override
	public int compare(Contact o1, Contact o2) {
		return o1.getPhoneNo().compareTo(o2.getPhoneNo());
	}
	

}
