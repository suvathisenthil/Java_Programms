package com.coll.dao;

import java.util.Comparator;

public class LastNameDescending implements Comparator<Contact>{

	@Override
	public int compare(Contact o1, Contact o2) {
		return o2.getLastName().compareTo(o1.getLastName());
	}
	

}
