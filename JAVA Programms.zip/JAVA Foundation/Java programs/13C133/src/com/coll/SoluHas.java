package com.coll;

import java.util.HashMap;
import java.util.Map;

public class SoluHas {

	public static void main(String[] args) {
		Map <Integer,String> map = new HashMap<Integer,String>();
		map.put(1, "AAA");
		map.put(2, "sss");
		map.put(3, "ddd");
		map.put(3, "vvv");
		System.out.println(map);
		System.out.println(map.put(5, "www"));
		System.out.println(map.remove(2));
		System.out.println(map);
		Map <Integer,String> map1 = new HashMap<Integer,String>();
		map.put(6, "stwve");
		map.put(7, "sss");
		map.put(8, "ddd");
		map.put(9, "vvv");
		map.putAll(map1);
		System.out.println(map.values());
		
		

	}

}
