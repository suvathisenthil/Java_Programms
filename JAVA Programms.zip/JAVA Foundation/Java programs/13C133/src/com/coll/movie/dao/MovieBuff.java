package com.coll.movie.dao;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class MovieBuff {
	private Map<String, List<Integer>> mObj = new HashMap<String,List<Integer>>();

	public MovieBuff() {
		super();
	}
	
	public void addMovie(String name,int rate) {
		if(mObj.containsKey(name)) {
			mObj.get(name).add(rate);
		}
		else {
			List <Integer> list = new LinkedList<Integer>();
			list.add(rate);
			mObj.put(name, list);
		}
		
	}

	@Override
	public String toString() {
		for(Map.Entry<String, List<Integer>> each : mObj.entrySet()) {
			double sum = 0;
			for(Integer ob : each.getValue()) {
				sum = sum+ob;
			}
			System.out.println(String.format("%s : %d reviews, average rating is %.1f/10",each.getKey(),each.getValue().size(),sum/each.getValue().size()));
		}
		return "";
	}
	
}

