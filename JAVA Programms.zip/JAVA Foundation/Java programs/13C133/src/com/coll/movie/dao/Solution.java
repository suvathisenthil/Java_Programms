package com.coll.movie.dao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Solution {
	public static void main(String[] args) throws IOException {
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		MovieBuff mb = new MovieBuff();
		int n = Integer.valueOf(bf.readLine());
		for(int i = 0;i < n; i++) {
			String name = bf.readLine();
			int rate = Integer.valueOf(bf.readLine());
			mb.addMovie(name, rate);
		}
		System.out.println(mb);
		} 
}

/*
 * package com.coll.movie.dao;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class MovieBuff {
	private	Map<String ,List<Integer>> mObj = new HashMap<String, List<Integer>>();
	
	public void addMovie(String name,int rate) {
		if(mObj.containsKey(name)) {
			mObj.get(name).add(rate);
		}
		else {
			List <Integer> list = new LinkedList<Integer>();
			list.add(rate);
			mObj.put(name, list);
			System.out.println(list);
		}
	}	
		

	public String toString() {
		for(Map.Entry<String, List<Integer>> each:mObj.entrySet()) {
			double sum = 0;
			for(Integer ob: each.getValue() ) {
				sum = sum+ob;
			}
			System.out.print(String.format("%s : %d reviews, average rating is %.1f/10",each.getKey(),each.getValue().size(),sum/each.getValue().size()));
		}
		return "";
	}
	
		

}


 */