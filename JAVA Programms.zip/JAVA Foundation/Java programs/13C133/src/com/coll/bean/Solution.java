package com.coll.bean;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import com.coll.dao.Contact;
import com.coll.dao.EmailIdAscending;
import com.coll.dao.EmailIdDescending;
import com.coll.dao.FirstLastNameAscending;
import com.coll.dao.FirstLastNameDescending;
import com.coll.dao.FirstNameAscending;
import com.coll.dao.FirstNameDescending;
import com.coll.dao.LastNameAscending;
import com.coll.dao.LastNameDescending;
import com.coll.dao.PhoneNoAscending;
import com.coll.dao.PhoneNoDescending;
public class Solution {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Set<Contact> list = null;
		switch(in.nextInt()) {
		case 1 :
			list = new TreeSet<Contact>(new FirstNameAscending());
			break;
		case 2 :
			list = new TreeSet<Contact>(new FirstNameDescending());
			break;
		case 3 :
			list = new TreeSet<Contact>(new LastNameAscending());
			break;
		case 4 :
			list = new TreeSet<Contact>(new LastNameDescending());
			break;
		case 5 :
			list = new TreeSet<Contact>(new FirstLastNameAscending());
			break;
		case 6 :
			list = new TreeSet<Contact>(new FirstLastNameDescending());
			break;
		case 7 :
			list = new TreeSet<Contact>(new PhoneNoAscending());
			break;
		case 8 :
			list = new TreeSet<Contact>(new PhoneNoDescending());
			break;
		case 9 :
			list = new TreeSet<Contact>(new EmailIdAscending());
			break;
		case 10 :
			list = new TreeSet<Contact>(new EmailIdDescending());
			break;	
	}
	list.add(new Contact("Swathi", "Senthil", "+919563142873", "swathi"));
	list.add(new Contact("Sona", "Senthil", "+91789451236", "sonu"));
	list.add(new Contact("Anusuya", "Devi", "8964751236", "sdev"));
	list.add(new Contact("Sona", "Senthil", "789451236", "sonu@gmail.com"));
	list.add(new Contact("Senthil", "Kumar", "9985741254", "senthil"));
	list.add(new Contact("Swathi", "Senthil", "9563142873", "swathi"));
	System.out.println(list);
	}
}
