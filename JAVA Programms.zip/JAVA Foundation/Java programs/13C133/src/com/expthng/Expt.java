package com.expthng;

public class Expt {
	public static void main(String[] args) {
		String ss = "user";
		String rr = "password";
		String s,r;
		try {
			 s = args[0];
			}catch(ArrayIndexOutOfBoundsException e) {
				//System.out.println(e);
				 s = "Guest";
			}
			try {
				 r = args[1];
				 
			}catch(ArrayIndexOutOfBoundsException d) {
				 r = "Guest";
			}
			try {
				if(args[0].equals(ss) &&  args[1].equals(rr)) {
					System.out.println("Login success");
				}
				else if(s == "Guest" || r =="Guest") {
					System.out.println("Login as Guest");
				}
				else {
					System.out.println("Login Unsuccess");
				}
				
			}catch(Exception e) {
				System.out.println(e);
			}
				
	}
	}