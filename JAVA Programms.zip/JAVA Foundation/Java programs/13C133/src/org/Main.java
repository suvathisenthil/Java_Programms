package org;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main {
	   public static void main(String args[]) throws FileNotFoundException {
		   Scanner s = new Scanner(new File("Input.txt"));
		       String a[][];
		       a = new String[10][7];
		       for(int i = 0; i<a.length; i++) {
		          for(int j =0;j<a[i].length;j++) {
		             a[i][j] = s.next();
		}
		}
		int b =1;
		int max =0;
		for(int i = 0; i<a.length; i++) {
		     if(max<=(Integer.valueOf(a[i][b]))) {
		           max = (Integer.valueOf(a[i][b]));
		}
		}
		 PrintWriter p = null;
		try {
			p = new PrintWriter("Output.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 p.println(max);
		 p.close();
		   }
		}
