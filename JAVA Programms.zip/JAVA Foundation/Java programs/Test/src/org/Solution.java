package org;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.stock.Item;

public class Solution {

	public static void main(String[] args)  throws IOException{
		Item item = null;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		switch(Integer.valueOf(br.readLine())) {
		case 1:
			item = new Item(br.readLine(), br.readLine(), br.readLine(), Double.valueOf(br.readLine()), br.readLine(), br.readLine(), Float.valueOf(br.readLine()));
			break;
		case 2:
			item = new Item(br.readLine(), br.readLine(), br.readLine(), Double.valueOf(br.readLine()), br.readLine(), br.readLine());
			break;
		}
		
		
		
		switch(Integer.valueOf(br.readLine())) {
		case 1:
			System.out.println(item);
			item.apply();
			if(item.getDiscountPercentage() == 0){
				System.out.println("No Discount. Better Luck Next Time");
			}
			else {
				System.out.println("Discount Applied. :)");
			}
		
			break;
		case 2:
			System.out.println(item);
			item.apply(Float.valueOf(br.readLine()));
			if(item.getDiscountPercentage() == 0){
				System.out.println("No Discount. Better Luck Next Time");
			}
			else {
				System.out.println("Discount Applied. :)");
			}
		
			break;
		case 3:
			System.out.println(item);
			item.remove();
			if(item.getDiscountPercentage() == 0){
				System.out.println("No Discount. Better Luck Next Time");
			}
			else {
				System.out.println("Discount Applied. :)");
			}
		
			break;
		}
		System.out.println(item);
	}

}