package com.stock;

public class Item {
	private String identity;
	private String name;
	private String manufacturer;
	private double maximumRetailPrice;
	private String manufacturedDate;
	private String expiryDate;
	private float discountPercentage = 0.0f;
	private double discountPrice = 0.0;
	
	public Item() {
		super();
		this.discountPercentage = 0.0f;
		this.discountPrice = 0.0;
	}
	public Item(String identity, String name, String manufacturer, double maximumRetailPrice, String manufacturedDate,
			String expiryDate, float discountPercentage) {
		super();
		this.identity = identity;
		this.name = name;
		this.manufacturer = manufacturer;
		this.maximumRetailPrice = maximumRetailPrice;
		this.manufacturedDate = manufacturedDate;
		this.expiryDate = expiryDate;
		this.discountPercentage = discountPercentage;
		this.discountPrice = this.maximumRetailPrice;
	}
	public Item(String identity, String name, String manufacturer, double maximumRetailPrice, String manufacturedDate,
			String expiryDate) {
		super();
		this.identity = identity;
		this.name = name;
		this.manufacturer = manufacturer;
		this.maximumRetailPrice = maximumRetailPrice;
		this.manufacturedDate = manufacturedDate;
		this.expiryDate = expiryDate;
		this.discountPrice = this.maximumRetailPrice;
	}
	public String getIdentity() {
		return identity;
	}
	public void setIdentity(String identity) {
		this.identity = identity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public double getMaximumRetailPrice() {
		return maximumRetailPrice;
	}
	public void setMaximumRetailPrice(double maximumRetailPrice) {
		this.maximumRetailPrice = maximumRetailPrice;
	}
	public String getManufacturedDate() {
		return manufacturedDate;
	}
	public void setManufacturedDate(String manufacturedDate) {
		this.manufacturedDate = manufacturedDate;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public float getDiscountPercentage() {
		return discountPercentage;
	}
	
	
	public void apply() {
		this.discountPrice = 0;
		this.discountPrice = this.maximumRetailPrice - ((this.discountPercentage/100) * this.maximumRetailPrice);
		
	}
	
	public void apply(float discountPercentage) {
		this.discountPrice = 0;
		this.discountPercentage = discountPercentage;
		this.discountPrice = this.maximumRetailPrice - ((this.discountPercentage/100) * this.maximumRetailPrice);
		
	}
	
	public void remove() {
		this.discountPercentage = 0.0f;
		this.discountPrice = this.maximumRetailPrice;		
	}
	
	public String toString() {
		return String.format("%-30s : ", "Item Identity")+this.identity+String.format("\n%-30s : ", "Item Name")+this.name+String.format("\n%-30s : ", "Item Manufacturer")+this.manufacturer+String.format("\n%-30s : ", "Item Manufacturing Date")+this.manufacturedDate+String.format("\n%-30s : ", "Item Expiry Date")+this.expiryDate+String.format("\n%-30s : ", "Maximum Retail Price")+String.format("Rs.%.2f",this.maximumRetailPrice)+String.format("\n%-30s : ", "Discount Percentage")+String.format("%.2f",this.discountPercentage)+String.format("\n%-30s : ", "Discount Amount")+String.format("Rs.%.2f",this.discountPrice);
	}
	

}
