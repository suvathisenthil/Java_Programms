package com.account;

public class Address {
	private String doorNumber,streetName,location,city,state,phoneNumber;
	private int pincode;
	public Address(String doorNumber, String streetName, String location, String city, String state, int pincode,String phoneNumber) {
		super();
		this.doorNumber = doorNumber;
		this.streetName = streetName;
		this.location = location;
		this.city = city;
		this.state = state;
		this.phoneNumber = phoneNumber;
		this.pincode = pincode;
	}
	public String getDoorNumber() {
		return doorNumber;
	}
	public void setDoorNumber(String doorNumber) {
		this.doorNumber = doorNumber;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "Delivery Address :\n------------------\n"+doorNumber+",\n"+streetName+","+location+",\n"+city+",\n"+state+" - "+""+pincode+".\nPhone No:"+phoneNumber;
		//System.out.print(" - %d .\nPhone No:%s",pincode,phoneNumber);
	//	return String.format("Delivery Address :\n------------------\n%s, %s,\n%s,\n%s - %d .\nPhone No:%s",doorNumber,streetName,location,city,state,pincode,phoneNumber);
	}

}


