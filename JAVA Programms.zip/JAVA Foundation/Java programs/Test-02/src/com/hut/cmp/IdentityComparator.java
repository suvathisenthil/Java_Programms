package com.hut.cmp;

import java.util.Comparator;

import com.hut.Pizza;

public class IdentityComparator implements Comparator<Pizza>{
	@Override
	public int compare(Pizza arg0, Pizza arg1) {
		return arg0.getIdentity().compareTo(arg1.getIdentity());
	}
}