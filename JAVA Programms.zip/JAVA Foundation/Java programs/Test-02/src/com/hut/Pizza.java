package com.hut;

public class Pizza {
	private String identity,name,toppings,size;
	private double price;

	

	public Pizza(String identity, String name, String toppings, String size, double price) {
		super();
		this.identity = identity;
		this.name = name;
		this.toppings = toppings;
		this.size = size;
		this.price = price;
	}

	public String getIdentity() {
		return identity;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getToppings() {
		return toppings;
	}

	public void setToppings(String toppings) {
		this.toppings = toppings;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return String.format("%-5s%-20s%-40s%-10s%.2f",identity,name,toppings,size,price);
	}
	
	

}
