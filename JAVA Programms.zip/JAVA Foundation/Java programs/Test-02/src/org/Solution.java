package org;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.account.Address;
import com.hut.Cart;
import com.hut.Pizza;

public class Solution {

	public static void main(String[] args) throws IOException {
		Pizza pizza = null;
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		String name = bf.readLine();
		List<Pizza> pizzaList = new ArrayList<Pizza>();
		pizzaList.add(new Pizza("PZ01","Veggie Surprise","Capsicum, Onion, Sweet Corn, Paprika","Medium",399.0));
		pizzaList.add(new Pizza("PZ02","Panner Delight","Onion, Tomato, Sweet Corn, Jalapeno","Medium",349.0));
		pizzaList.add(new Pizza("PZ03","Chicken Hot n Spicy","Red Paprkia, Onion, Jalapeno","Medium",499.0));
		pizzaList.add(new Pizza("PZ04","Tikka Treat","Capsicum, Onion, Mushroom","Medium",599.0));
		
		Address address = new Address(bf.readLine(), bf.readLine(), bf.readLine(), bf.readLine(), bf.readLine(), Integer.valueOf(bf.readLine()), bf.readLine());
		Cart cart = new Cart(name, address);
		String a;
		do{
			String s = bf.readLine();
				switch(s) {
				case "1" :
					int index = Integer.valueOf(bf.readLine());
					cart.addPizza(pizzaList.get(index -1 ));
					break;
				case "2" :
					int index1 = Integer.valueOf(bf.readLine());
					cart.removePizza(pizzaList.get(index1 -1 ));
					break;
			}
			a = bf.readLine();	
			}while(!a.equalsIgnoreCase("no"));
		    System.out.println("Name: "+name);
			System.out.println(address);
			System.out.println(cart);
	}

}
